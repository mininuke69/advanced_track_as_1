KING'S PALINDROME LIST — TASK 2 TEST CASES

Every case is a complete Task 2 input:
Line 1: 2
Line 2: N
Line 3: N positive integers

All generated input numbers have an odd number of digits and at most 17 digits.
The corrected palindrome lists are also checked for distinctness, matching the assignment's stated observation.

EXPECTED OUTPUTS
01_max_chain_9: N=15, expected Task 2 output=9
  one maximum X: 12345678987654321

02_two_max_chains: N=21, expected Task 2 output=8
  one maximum X: 246824686428642

03_correction_edges: N=13, expected Task 2 output=5
  one maximum X: 864212468

04_no_chain_100: N=100, expected Task 2 output=1
  one maximum X: 98993957075939989

05_large_5000: N=5000, expected Task 2 output=9
  one maximum X: 12345678987654321

06_max_50000: N=50000, expected Task 2 output=9
  one maximum X: 12345678987654321

07_boundary_patterns: N=17, expected Task 2 output=5
  one maximum X: 864212468

08_medium_1000: N=1000, expected Task 2 output=6
  one maximum X: 9753186813579

Design notes:
01: 9-element chain, the maximum possible chain length for <=17-digit numbers.
02: two different 8-element chains; checks whether an implementation finds the true global maximum.
03: correction-heavy values plus a 5-element chain; exercises next-palindrome logic.
04: 100 unrelated 17-digit palindromes; expected maximum is 1.
05: N=5,000 performance test with a hidden 9-element chain.
06: N=50,000 maximum-size performance test with a hidden 9-element chain.
07: large boundary/carry-style values plus a 5-element chain.
08: N=1,000 mixed odd lengths with a 6-element chain and many distractors.